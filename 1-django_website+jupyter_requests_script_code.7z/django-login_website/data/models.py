from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
# Create your models here.

class Articles(models.Model):
    title = models.CharField(max_length=128, verbose_name="标题")
    content = models.TextField(verbose_name="正文")
    create_time = models.DateTimeField(default=timezone.now, verbose_name="创建时间")
    read_num = models.IntegerField(default=1,verbose_name="阅读量")

    author = models.ForeignKey(User, related_name="articles", verbose_name="作者")


    def __str__(self):
        return "{}【作者：{}】".format(self.title,self.author.username)

    class Meta:
        managed = True
        db_table = "articles"
        verbose_name = "文章"
        verbose_name_plural = verbose_name

'''
from django.contrib.auth.models import User
from data.models import Articles
from faker import Faker
import random
from random import randint
init = Faker(locale='zh-cn')
fake = Faker()


for i in range(0,5):
    User.objects.create_user(username=fake.name(),email=fake.email(),password=fake.password())

for i in range(1,5):
    Articles.objects.create(title=init.text(5),content=init.text(5500),read_num=randint(1,1000000),author=random.choice(User.objects.filter(is_superuser=False)),create_time=fake.date_time())

'''